package com.example.appqci;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * Created by User on 2/28/2017.
 */

public class Tab2Fragment extends Fragment {
    private static final String TAG = "Tab2Fragment";

    private BarChart barChart;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2_fragment,container,false);
        barChart = (BarChart) view.findViewById(R.id.bargraph);
        barChart.setDrawBarShadow(false);
        barChart.setDrawValueAboveBar(true);
        barChart.setPinchZoom(false);
        barChart.setDrawGridBackground(true);

        ArrayList<BarEntry> barEntries = new ArrayList<>();

        barEntries.add(new BarEntry(0, 45f));//lo info dentro de los parametros son datos de basura
        barEntries.add(new BarEntry(1, 50f));
        barEntries.add(new BarEntry(2, 34f));
        barEntries.add(new BarEntry(3, 65f));
        barEntries.add(new BarEntry(4, 10f));
        barEntries.add(new BarEntry(5, 24f));




        BarDataSet barDataSet = new BarDataSet(barEntries, "Día");
        barDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        BarData barData = new BarData(barDataSet);

        barChart.setData(barData);
        String [] months = new String[]{"Lun", "Mar", "Mie", "Jue", "Vie", "Sab"};
        XAxis x_axis = barChart.getXAxis();
        x_axis.setValueFormatter(new MyXAxisValueFormatter(months));
        x_axis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //barChart.invalidate();
        /**/;
        barChart.setTouchEnabled(true);
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(true);


        return view;
    }

    public class MyXAxisValueFormatter implements IAxisValueFormatter{
        private String[] nValues;
        public MyXAxisValueFormatter(String[] values) {
            this.nValues = values;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis){
            return nValues[(int)value];
        }

    }


}
